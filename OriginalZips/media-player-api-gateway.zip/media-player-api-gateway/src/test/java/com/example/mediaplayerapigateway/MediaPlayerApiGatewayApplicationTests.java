package com.example.mediaplayerapigateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MediaPlayerApiGatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
