package com.cg.mediaplayeruser;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MediaPlayerUserApplication {

	public static void main(String[] args) {
		SpringApplication.run(MediaPlayerUserApplication.class, args);
	}

}
