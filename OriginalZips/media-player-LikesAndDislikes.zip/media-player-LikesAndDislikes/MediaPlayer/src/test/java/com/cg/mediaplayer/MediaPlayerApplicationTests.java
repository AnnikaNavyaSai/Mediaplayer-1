package com.cg.mediaplayer;
import com.cg.mediaplayer.entites.Media;
import com.cg.mediaplayer.exception.IdNotFoundException;
import com.cg.mediaplayer.repository.MediaRepository;
import com.cg.mediaplayer.serviceimpl.MediaServiceImpl;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Optional;

import static org.mockito.Mockito.*;

public class MediaPlayerApplicationTests {

    @Mock
    private MediaRepository mediaRepository;

    @InjectMocks
    private MediaServiceImpl mediaService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testAddLike() {
        int videoId = 1;
        Media media = new Media();
        media.setLikes(0);

        when(mediaRepository.findByVideoId(videoId)).thenReturn(Optional.of(media));

        mediaService.addLike(videoId);

        Assertions.assertEquals(1, media.getLikes());
        verify(mediaRepository, times(1)).save(media);
    }

    @Test
    void testAddDislike() {
        int videoId = 1;
        Media media = new Media();
        media.setDislikes(0);

        when(mediaRepository.findByVideoId(videoId)).thenReturn(Optional.of(media));

        mediaService.addDislike(videoId);

        Assertions.assertEquals(1, media.getDislikes());
        verify(mediaRepository, times(1)).save(media);
    }

    @Test
    void testGetTotalLikes() {
        int videoId = 1;
        Media media = new Media();
        media.setLikes(10);

        when(mediaRepository.findByVideoId(videoId)).thenReturn(Optional.of(media));

        int totalLikes = mediaService.getTotalLikes(videoId);

        Assertions.assertEquals(10, totalLikes);
    }

    @Test
    void testGetTotalDislikes() {
        int videoId = 1;
        Media media = new Media();
        media.setDislikes(5);

        when(mediaRepository.findByVideoId(videoId)).thenReturn(Optional.of(media));

        int totalDislikes = mediaService.getTotalDislikes(videoId);

        Assertions.assertEquals(5, totalDislikes);
    }

    @Test
    void testRemoveLike() {
    	int videoId = 1;
        Media media = new Media();
        media.setLikes(2);

        when(mediaRepository.findByVideoId(videoId)).thenReturn(Optional.of(media));

        mediaService.removeLike(videoId);

        Assertions.assertEquals(1, media.getLikes());
        verify(mediaRepository, times(1)).save(media);
    }

    @Test
    void testRemoveLikeWithZeroLikes() {
    	int videoId = 1;
        Media media = new Media();
        media.setLikes(0);

        when(mediaRepository.findByVideoId(videoId)).thenReturn(Optional.of(media));

        mediaService.removeLike(videoId);

        Assertions.assertEquals(0, media.getLikes());
        verify(mediaRepository, times(1)).save(media);
    }

    @Test
    void testRemoveDislike() {
    	int videoId = 1;
        Media media = new Media();
        media.setDislikes(3);

        when(mediaRepository.findByVideoId(videoId)).thenReturn(Optional.of(media));

        mediaService.removeDislike(videoId);

        Assertions.assertEquals(2, media.getDislikes());
        verify(mediaRepository, times(1)).save(media);
    }

    @Test
    void testRemoveDislikeWithZeroDislikes() {
    	int videoId = 1;
        Media media = new Media();
        media.setDislikes(0);

        when(mediaRepository.findByVideoId(videoId)).thenReturn(Optional.of(media));

        mediaService.removeDislike(videoId);

        Assertions.assertEquals(0, media.getDislikes());
        verify(mediaRepository, times(1)).save(media);
    }

    @Test
    void testAddLikeWithInvalidVideoId() {
        int videoId = 1;

        when(mediaRepository.findByVideoId(videoId)).thenReturn(Optional.empty());

        Assertions.assertThrows(IdNotFoundException.class, () -> mediaService.addLike(videoId));
        verify(mediaRepository, never()).save(any());
    }

    @Test
    void testAddDislikeWithInvalidVideoId() {
        int videoId = 1;

        when(mediaRepository.findByVideoId(videoId)).thenReturn(Optional.empty());

        Assertions.assertThrows(IdNotFoundException.class, () -> mediaService.addDislike(videoId));
        verify(mediaRepository, never()).save(any());
    }

    @Test
    void testGetTotalLikesWithInvalidVideoId() {
        int videoId = 1;

        when(mediaRepository.findByVideoId(videoId)).thenReturn(Optional.empty());

        Assertions.assertThrows(IdNotFoundException.class, () -> mediaService.getTotalLikes(videoId));
    }

    @Test
    void testGetTotalDislikesWithInvalidVideoId() {
    	int videoId = 1;

        when(mediaRepository.findByVideoId(videoId)).thenReturn(Optional.empty());

        Assertions.assertThrows(IdNotFoundException.class, () -> mediaService.getTotalDislikes(videoId));
    }

    @Test
    void testRemoveLikeWithInvalidVideoId() {
    	int videoId = 1;

        when(mediaRepository.findByVideoId(videoId)).thenReturn(Optional.empty());

        Assertions.assertThrows(IdNotFoundException.class, () -> mediaService.removeLike(videoId));
        verify(mediaRepository, never()).save(any());
    }

    @Test
    void testRemoveDislikeWithInvalidVideoId() {
    	int videoId = 1;

        when(mediaRepository.findByVideoId(videoId)).thenReturn(Optional.empty());

        Assertions.assertThrows(IdNotFoundException.class, () -> mediaService.removeDislike(videoId));
        verify(mediaRepository, never()).save(any());
    }
}
