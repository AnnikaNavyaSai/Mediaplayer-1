package com.cg.mediaplayer.serviceimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.mediaplayer.entites.Media;
import com.cg.mediaplayer.exception.IdNotFoundException;
import com.cg.mediaplayer.repository.MediaRepository;
import com.cg.mediaplayer.service.MediaService;

@Service
@Transactional
public class MediaServiceImpl implements MediaService{
	@Autowired
    private  MediaRepository mediaRepository;
	@Override
	public void addLike(Media media) {
		
        media.setLikes(media.getLikes() + 1);
        mediaRepository.save(media);
		
	}

	@Override
	public void addDislike(Media media) {
		 
	        media.setDislikes(media.getDislikes() + 1);
	        mediaRepository.save(media);
		
	}

	@Override
	public int getTotalLikes(int videoId) {
		Media media = mediaRepository.findByVideoId(videoId).orElseThrow(()-> new IdNotFoundException("video Id not found "));
		return media.getLikes();
	}

	@Override
	public int getTotalDislikes(int videoId) {
		Media media = mediaRepository.findByVideoId(videoId).orElseThrow(()-> new IdNotFoundException("video Id not found "));
		return media.getDislikes();
	}

	@Override
	public void removeLike(int videoId) {
		// TODO Auto-generated method stub
		Media media = mediaRepository.findByVideoId(videoId).orElseThrow(()-> new IdNotFoundException("video Id not found "));
		if(media.getLikes()==0) {
			media.setLikes(0);
			
		}
		else {
			 media.setLikes(media.getLikes() - 1);
		}
       
        mediaRepository.save(media);
		
	}

	@Override
	public void removeDislike(int videoId) {
		// TODO Auto-generated method stub
		Media media = mediaRepository.findByVideoId(videoId).orElseThrow(()-> new IdNotFoundException("video Id not found "));
		if(media.getDislikes()==0) {
			media.setDislikes(0);
			
		}
		else {
			 media.setDislikes(media.getDislikes() - 1);
		}
       
        mediaRepository.save(media);
		
	}
	
}
