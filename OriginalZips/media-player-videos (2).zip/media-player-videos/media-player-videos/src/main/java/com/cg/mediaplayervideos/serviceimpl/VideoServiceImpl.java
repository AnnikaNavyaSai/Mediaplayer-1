package com.cg.mediaplayervideos.serviceimpl;

import java.io.File;

import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.util.Date;
import java.util.List;

import org.hibernate.validator.internal.constraintvalidators.bv.time.futureorpresent.FutureOrPresentValidatorForLocalDate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.cg.mediaplayervideos.entites.Videos;
import com.cg.mediaplayervideos.repository.VideoRepository;
import com.cg.mediaplayervideos.service.VideoService;

import jakarta.transaction.Transactional;
import net.bramp.ffmpeg.FFprobe;
import net.bramp.ffmpeg.probe.FFmpegProbeResult;
import net.bramp.ffmpeg.probe.FFmpegStream;

@Service
public class VideoServiceImpl implements VideoService {
	
	@Autowired
	private VideoRepository videoRepository;

	@Override
	@Transactional
	public Videos uploadVideos(MultipartFile file, String videoName,  int userId,
			String category) throws IOException  {
		String filePath = "./Videos" + file.getOriginalFilename();
		try {
			file.transferTo(new File(filePath));
		} catch (IllegalStateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Videos video = new Videos();
		
		video.setVideoName(videoName);
		video.setDate(LocalDate.now());
		video.setUserId(userId);
		video.setCategory(category);
		video.setViewCount(getViewCount(video.getVideoId()));
		
		
		return videoRepository.save(video);
	}

	@Override
	public long getViewCount(int videoId) {
		Videos video = videoRepository.findById(videoId).orElse(null);
        if (video != null) {
            return video.getViewCount();
        }
		
		return 0;
	}

	@Override

	 public void incrementViewCount(int videoId) {
        // Retrieve the video from the database
        Videos video = videoRepository.findById(videoId).orElse(null);

        if (video != null) {
            // Increment the view count
            long viewCount = video.getViewCount();
            viewCount++;
            video.setViewCount(viewCount);

            // Save the updated video object
            videoRepository.save(video);
        }
    }

	@Override
	public String deleteVideos() {
		videoRepository.deleteAll();
		return "All videos are deleted";
	}

	@Override
	public String deleteVideoById(int videoId) {
		videoRepository.deleteById(videoId);
		return "video is deleted by user who's userId is "+videoId;
	}

	@Override
	public List<Videos> getAllVideos() {
		return videoRepository.findAll();
	}

	@Override
	public Videos getVideosById(int userId) {
		return videoRepository.findById(userId).get();
	}

	@Override
	public List<Videos> searchByCategory(String category) {
		// TODO Auto-generated method stub
		return videoRepository.findByCategory(category);
	}

	
	
	

}
