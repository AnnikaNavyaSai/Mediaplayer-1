package com.cg.mediaplayervideos.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.mediaplayervideos.entites.Videos;

@Repository
public interface VideoRepository extends JpaRepository<Videos, Integer> {
	
	public List<Videos> findByCategory(String category) ;

}
