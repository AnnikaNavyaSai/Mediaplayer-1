package com.cg.mediaplayervideos.controller;

import java.io.IOException;
import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.cg.mediaplayervideos.entites.Videos;
import com.cg.mediaplayervideos.service.VideoService;

@RestController
@RequestMapping("/videos")
public class VideoController {
	
	@Autowired
	private VideoService videoService;
	
	@PostMapping
	public Videos uploadVideos(@RequestParam("file") MultipartFile file,@RequestParam String videoName,@RequestParam int userId,@RequestParam String category) throws IOException
	{
		return videoService.uploadVideos(file, videoName,  userId, category);
	}
	
	@GetMapping("/getviewcount/{videoId}")
	public long getViewCount(@PathVariable int videoId)
	{
		return videoService.getViewCount(videoId);
	}
	
	@PostMapping("/viewcount/{videoId}")
	public void incrementVideoCount(@PathVariable int videoId)
	{
		 videoService.incrementViewCount(videoId);
	}
	
	@GetMapping
	public List<Videos> getAllVideos()
	{
		return videoService.getAllVideos();
	}
	
	@GetMapping("/getvideo/{userId}")
	public Videos getVideoById(@PathVariable int userId)
	{
		return videoService.getVideosById(userId);
	}
	
	@GetMapping("/category/{category}")
	public List<Videos> findByCategory(@PathVariable String category)
	{
		return videoService.searchByCategory(category);
	}
	
	@DeleteMapping
	public String deleteAllVideos()
	{
		 return videoService.deleteVideos();
	}
	
	@DeleteMapping("/delete/{videoId}")
	public String deleteById(@PathVariable int videoId)
	{
		return videoService.deleteVideoById(videoId);
	}
	

}
