package com.cg.mediaplayervideos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MediaPlayerVideosApplicationTests {

	@Test
	void contextLoads() {
	}

}
