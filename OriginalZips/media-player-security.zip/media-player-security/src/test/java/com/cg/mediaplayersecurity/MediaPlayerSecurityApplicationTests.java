package com.cg.mediaplayersecurity;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MediaPlayerSecurityApplicationTests {

	@Test
	void contextLoads() {
	}

}
