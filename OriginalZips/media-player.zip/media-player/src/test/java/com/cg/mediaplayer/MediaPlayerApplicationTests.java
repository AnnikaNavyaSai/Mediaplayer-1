package com.cg.mediaplayer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MediaPlayerApplicationTests {

	@Test
	void contextLoads() {
	}

}
