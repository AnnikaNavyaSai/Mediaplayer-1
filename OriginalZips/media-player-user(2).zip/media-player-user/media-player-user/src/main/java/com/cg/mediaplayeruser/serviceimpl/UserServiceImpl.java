package com.cg.mediaplayeruser.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.mediaplayeruser.entites.Users;
import com.cg.mediaplayeruser.repository.UserRepositroy;
import com.cg.mediaplayeruser.service.UserService;

@Service
public class UserServiceImpl implements UserService {
	
	@Autowired
	private UserRepositroy userRepository;
	

	@Override
	public Users addUser(Users user) {
		// TODO Auto-generated method stub
		Users u = userRepository.save(user);
		return u;
	}


	@Override
	public List<Users> getAllUsers() {
		// TODO Auto-generated method stub
		return userRepository.findAll();
	}


	@Override
	public Users getUserById(int userId) {
		// TODO Auto-generated method stub
		return userRepository.findById(userId).get();
	}


	@Override
	public String deleteAllUsers() {
		// TODO Auto-generated method stub
		userRepository.deleteAll();
		return "all users are deleted";
	}


	@Override
	public String deleteByUserId(int userId) {
		// TODO Auto-generated method stub
		userRepository.deleteById(userId);
		return "a user is deleted who's employee id is "+ userId;
	}

}
